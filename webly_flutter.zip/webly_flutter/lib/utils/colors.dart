import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

const primaryColor1 = Color(0xFF195CDD);
const textColorPrimary = Color(0xFF212121);
const textColorSecondary = Color(0xFF757575);

const shadow_color = Color(0x95E9EBF0);
const darkCardColor = Color(0xFF1D2939);